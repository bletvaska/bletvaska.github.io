WIDTH = 288
HEIGHT = 512
TITLE = 'Flappy Bird GVPT SPST MT SK'

GRAVITY = 0.3
FLAP_SPEED = 6.5
SPEED = 3

flappy = Actor('flappy')
flappy.x = WIDTH / 2
flappy.y = HEIGHT / 2
flappy.dy = 0

pipe_upper = Actor('pipe.upper')
pipe_upper.left = WIDTH
pipe_lower = Actor('pipe.lower')
pipe_lower.left = WIDTH


def update():
    flappy.y += (2*flappy.dy + GRAVITY) / 2
    flappy.dy += GRAVITY

    if flappy.top > HEIGHT:
        print('game over')
        quit()

    pipe_upper.x -= 1
    pipe_lower.x -= 1
    if pipe_upper.right <= 0:
        pipe_upper.left = WIDTH
        pipe_lower.left = WIDTH

    if flappy.colliderect(pipe_upper) == True or flappy.colliderect(pipe_lower) == True:
        print('si dostal trupkou po hlave')
        print('ta ty trupka')
        quit()


def draw():
    screen.blit('flappy.background', (0, 0))

    pipe_upper.draw()
    pipe_lower.draw()

    flappy.draw()



def on_key_down(key):
    if key == keys.SPACE:
        flappy.dy =-FLAP_SPEED

