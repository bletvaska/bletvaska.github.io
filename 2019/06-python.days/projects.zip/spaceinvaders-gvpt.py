WIDTH = 640
HEIGHT = 480
TITLE = 'Space Invaders in GVPT SPST, MT, SK'

invader = Actor('invader')
invader.left = 0
invader.top = 0
invader.dx = 1
invader.speed = 3

player = Actor('player')
player.x = WIDTH / 2
player.bottom = HEIGHT
player.speed = 5


def update():
    # handle player
    if keyboard.left == True:
        player.x -= player.speed
        if player.left < 0:
            player.left = 0

    if keyboard.right == True:
        player.x += player.speed
        if player.right > WIDTH:
            player.right = WIDTH


    # handle invader
    invader.x = invader.x + invader.dx * invader.speed

    if invader.right >= WIDTH:
        invader.dx *= -1
        invader.y += invader.height / 2

    if invader.left <= 0:
        invader.dx *= -1
        invader.y += invader.height / 2

    if invader.bottom >= HEIGHT:
        print('game over')
        print('you have lost the Earth planet')
        print('you have to move to mars')
        print('say hello to elon musk')
        quit()


    if invader.colliderect(player) == True:
        print('ta uzemnil')
        quit()

def draw():
    screen.clear()
    invader.draw()
    player.draw()





