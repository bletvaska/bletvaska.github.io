WIDTH = 640
HEIGHT = 800
TITLE = 'mArkanoid'


class Ball(Actor):
    def __init__(self):
        super().__init__('ball-blue')
        self.x = WIDTH / 2
        self.y = HEIGHT / 2
        self.speed = 7
        self.dx = 1
        self.dy = -1

    def update(self):
        # aktualizujem pohyb
        self.x = self.speed * self.dx + self.x
        self.y = self.speed * self.dy + self.y

        # kontrola okrajov obrazovky
        if self.right >= WIDTH:
            self.right = WIDTH
            self.dx *= -1
        elif self.top <= 0:
            self.top = 0
            self.dy *= -1
        elif self.left <= 0:
            self.left = 0
            self.dx *= -1
        elif self.bottom >= HEIGHT:
            # game over
            self.bottom = HEIGHT
            self.dy *= -1

        # kontrola kolizie s tehlami
        for brick in bricks:
            if self.colliderect(brick):
                self.dy *= -1
                bricks.remove(brick)
                # aktualizovat skore
                break

        # kontrola kolizie s hracom
        if self.colliderect(paddle):
            self.dy *= -1


class Brick(Actor):
    def __init__(self):
        super().__init__('brick-purple')


class Paddle(Actor):
    def __init__(self):
        super().__init__('paddle-blue')
        self.bottom = HEIGHT
        self.x = WIDTH / 2
        self.speed = 10

    def update(self):
        if keyboard.left == True:
            self.x -= self.speed
            if self.left < 0:
                self.left = 0

        if keyboard.right == True:
            self.x += self.speed
            if self.right > WIDTH:
                self.right = WIDTH


def update():
    ball.update()
    paddle.update()


def draw():
    screen.clear()

    # vykresli vsetky tehly
    for brick in bricks:
        brick.draw()

    # vykresli lopticku aj palku
    ball.draw()
    paddle.draw()


# globalne premenne (fuj)
paddle = Paddle()
ball = Ball()
bricks = []

# vygeneruj tehly
for row in range(5):
    for col in range(10):
        brick = Brick()
        brick.left = col * brick.width
        brick.top = row * brick.height
        bricks.append(brick)
