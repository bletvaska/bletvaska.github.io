#!/usr/bin/env pgzrun
import random

WIDTH = 288
HEIGHT = 512
TITLE = "Flap.py"

GRAVITY = 0.3
FLAP_SPEED = 6.5
GAP = 150
SPEED = 1


class Flappy(Actor):
    def __init__(self):
        super().__init__('yellowbird-midflap')
        # umiestni do stredu obrazovky
        self.x = WIDTH / 2
        self.y = HEIGHT / 2

        # zrychlenie
        self.dy = 0.0
        self.dead = False
        self.score = 0

    def update(self):
        self.y += (2 * self.dy + GRAVITY) / 2
        self.dy += GRAVITY

        if self.top > HEIGHT:
            self.dead = True

        if self.top <= 0:
            self.top = 0

class Pipe():
    def __init__(self):
        self.upper = Actor('pipe-green-top')
        self.lower = Actor('pipe-green')
        self.restart_pipe()

    def restart_pipe(self):
        gap_top = random.randint(100, 300)
        self.upper.left = WIDTH
        self.upper.bottom = gap_top
        self.lower.left = WIDTH
        self.lower.top = gap_top + GAP

    def update(self):
        self.upper.left -= SPEED
        self.lower.left -= SPEED

        if self.upper.right <= 0:
            self.restart_pipe()
            flappy.score += 1

        if self.upper.colliderect(flappy) or self.lower.colliderect(flappy):
            flappy.dead = True


    def draw(self):
        self.upper.draw()
        self.lower.draw()


flappy = Flappy()
pipe = Pipe()

def on_key_down(key):
    if key == keys.SPACE:
        flappy.dy = -FLAP_SPEED


def update():
    if flappy.dead:
        return

    pipe.update()
    flappy.update()


def draw():
    screen.blit('background-day', (0, 0))

    pipe.draw()
    flappy.draw()

    if flappy.dead:
        actor = Actor('gameover')
        actor.pos = WIDTH / 2, HEIGHT / 2
        actor.draw()
