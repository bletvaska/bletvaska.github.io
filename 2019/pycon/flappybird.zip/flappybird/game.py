HEIGHT = 512
WIDTH = 288
TITLE = "Flap.py"

GRAVITY = 0.3
FLAP_SPEED = 6.5
SPEED = 3

flappy = Actor('flappy')
flappy.x = WIDTH / 2
flappy.y = HEIGHT / 2
flappy.dy = 0

pipe = Actor('pipe-upper')
pipe.left = WIDTH
pipe.bottom = HEIGHT / 2

def update():
    flappy.y += (2*flappy.dy + GRAVITY) / 2
    flappy.dy += GRAVITY

    pipe.left -= SPEED

    if pipe.right < 0:
        pipe.left = WIDTH

    if pipe.colliderect(flappy) == True:
        print('si sa trafil')
        quit()

    if flappy.top > HEIGHT:
        print('si to skoncil')
        quit()

def draw():
    screen.blit('background',(0,0))
    pipe.draw()
    flappy.draw()

def on_key_down(key):
    if key == keys.SPACE:
        flappy.dy =-FLAP_SPEED
