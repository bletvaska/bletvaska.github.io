TITLE='mocna hra'
WIDTH=640
HEIGHT=480

score = 0

ball = Actor('ball')
ball.x = WIDTH / 2
ball.y = HEIGHT / 2
ball.dx = 1
ball.dy = 1
ball.speed = 5

paddle = Actor('paddle')
paddle.bottom = HEIGHT
paddle.x = WIDTH / 2
paddle.speed = 7

bricks = []
line = 0
for color in ('red', 'green', 'grey', 'purple', 'blue'):
    for count in range(10):
        brick = Actor(f'brick.{color}')
        brick.left = count * brick.width
        brick.top = brick.height * line
        bricks.append(brick)
    line += 1

def update():
    global score

    ball.x += ball.dx * ball.speed
    ball.y += ball.dy * ball.speed

    if ball.right > WIDTH:
        ball.dx = -1 # left
    if ball.left < 0:
        ball.dx = 1 # right
    if ball.top < 0:
        ball.dy = 1 # down
    if ball.bottom > HEIGHT:
        # ball.dy = -1 # up
        print('Game Over Man')
        quit()
    paddle.x = ball.x
    if keyboard.left == True:
        paddle.x -= paddle.speed

        if paddle.left < 0:
            paddle.left = 0

    if keyboard.right == True:
        paddle.x += paddle.speed

        if paddle.right > WIDTH:
            paddle.right = WIDTH

    if paddle.colliderect(ball) == True:
        ball.dy = -1 # up
        ball.bottom = paddle.top

    for brick in bricks:
        if brick.colliderect(ball) == True:
            ball.dy *= -1
            bricks.remove(brick)
            score += 1

            if score % 10 == 0:
                ball.speed += 1

            break

    if len(bricks) == 0:
        print('Well Done')
        quit()


def draw():
    screen.blit('arkanoid.background', (0,0))
    for brick in bricks:
        brick.draw()

    ball.draw()

    paddle.draw()
