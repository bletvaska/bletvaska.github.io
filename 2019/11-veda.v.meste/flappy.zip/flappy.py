# Tu napíšte svoj kód :-)
HEIGHT = 512
WIDTH = 288
TITLE = 'flappy'

flappy = Actor('flappy')
flappy.x = WIDTH / 2
flappy.y = HEIGHT / 2
flappy.vy = 0

trupka = Actor('pipe.upper')
trupka.left = WIDTH


def draw():
    screen.blit('flappy.background', (0,0))
    trupka.draw()
    flappy.draw()


def update():
    flappy.vy = flappy.vy + 0.3
    flappy.y = flappy.y + flappy.vy

    trupka.x = trupka.x - 1
    if trupka.right < 0:
        trupka.left = WIDTH

    if flappy.colliderect(trupka):
        print('si mrtvy')
        quit()

def on_key_down():
    flappy.vy = -6.5

