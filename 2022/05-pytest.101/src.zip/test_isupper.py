def test_moj_prvy_test():
    assert 'JANO'.isupper()


def test_moj_zly_test():
    assert 'jano'.isupper()


def test_moj_prvy_ciselny_test():
    result = 40 + 1
    assert 42 == result

