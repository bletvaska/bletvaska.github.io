#!/usr/bin/env python

import arcade

class Flappy(arcade.Window):
    def __init__(self):
        super().__init__()

game = Flappy()
arcade.run()
