from states.init import Init

class Device():
    def __init__(self):
        self.ldr = None
        self.pir = None
        self.light = None
        self.config = None
        self.state = Init(self)
        
    def get_intensity(self):
        """
        Returns relative light intensity as percent.
        """
        value = int(100 - self.ldr.read_u16() / 65535 * 100)
        print(f'   insensity {value}%')
        return value
    
    def is_movement(self):
        """
        Returns True, if PIR sensor detects movement, False otherwise.
        """
        value = self.pir.value() == 1
        print(f'   movement: {value}')
        return value
        
    def run(self):
        """
        Main application loop.
        """
        while True:
            state = self.state
            
            state.on_enter()
            while state == self.state:
                state.exec()
            state.on_exit()
        