# Pin of the PIR sensor
PIR_PIN = 9

# Pin of the LDR sensor
LDR_PIN = 27

# Pin of the NeoPixel light
NP_PIN = 28

# Location of settings file
SETTINGS_FILE = 'settings.json'
