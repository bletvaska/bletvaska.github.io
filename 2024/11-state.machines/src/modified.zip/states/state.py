"""
(Abstract) state for all states - parent state.
"""
from builtins import NotImplementedError


class State:
    def __init__(self, device):
        self.device = device
        
    def on_enter(self):
        """
        Executed on state entry.
        """
        pass
    
    def exec(self):
        """
        Main state function. The state logic goes here.
        """
        raise NotImplementedError('This method was not yet implemented.')
    
    def on_exit(self):
        """
        Executed on state exit.
        """
        pass
