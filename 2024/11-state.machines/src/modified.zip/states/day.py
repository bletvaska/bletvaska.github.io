"""
State represents the behavior in Day mode.
"""
from time import sleep

from .state import State

class Day(State):
    def on_enter(self):
        print('>> Day State')
        
    def exec(self):
        intensity = self.device.get_intensity()
        if intensity < self.device.config['nightTreshold']:
            from .night import Night
            self.device.state = Night(self.device)
            return
        
        sleep(1)

        