"""
State represents the behavior in Night mode.
"""
from time import sleep

from .state import State
from .movement import Movement

class Night(State):
    def on_enter(self):
        print('>> Night State')
        
    def exec(self):
        intensity = self.device.get_intensity()
        if intensity > self.device.config['dayTreshold']:
            from .day import Day
            self.device.state = Day(self.device)
            return
        
        if self.device.is_movement():
            self.device.state = Movement(self.device)
            return
        
        sleep(1)
        
