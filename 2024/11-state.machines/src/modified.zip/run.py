from device import Device

if __name__ == '__main__':
    device = Device()
    device.run()
