from device import Device

device = Device()
device.run()
