from time import sleep

from .state import State

class Day(State):
    def exec(self):
        print('>> Day State')
        
        while True:
            intensity = self.device.get_intensity()
            if intensity < self.device.config['nightTreshold']:
                from .night import Night
                self.device.state = Night(self.device)
                break
            sleep(1)

        