class State:
    def __init__(self, device):
        self.device = device
        
    def on_enter(self):
        pass
    
    def exec(self):
        pass
    
    def on_exit(self):
        pass