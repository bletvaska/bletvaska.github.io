import json
from machine import Pin, ADC
from neopixel import NeoPixel

from .state import State
from .day import Day
from config import PIR_PIN, LDR_PIN, NP_PIN

class Init(State):
    def exec(self):
        print('>> Init State')
        
        self.device.ldr = ADC(Pin(LDR_PIN, Pin.IN))
        self.device.pir = Pin(PIR_PIN, Pin.IN)
        self.device.light = NeoPixel(Pin(NP_PIN, Pin.OUT), 1)
        
        with open('config.json', 'r') as file:
            self.device.config = json.load(file)
            
        self.device.state = Day(self.device)
            