from time import sleep

from .state import State

class Movement(State):
    def on_enter(self):
        self.device.light[0] = (255, 255, 255)
        self.device.light.write()
        
    def exec(self):
        print('>> Movement State')
        
        while True:
            if not self.device.is_movement():
                from .night import Night
                self.device.state = Night(self.device)
                break
            sleep(1)
            
    def on_exit(self):
        self.device.light[0] = (0, 0, 0)
        self.device.light.write()

            