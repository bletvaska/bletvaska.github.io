from time import sleep

from .state import State
from .movement import Movement

class Night(State):
    def exec(self):
        print('>> Night State')
        
        while True:
            intensity = self.device.get_intensity()
            if intensity > self.device.config['dayTreshold']:
                from .day import Day
                self.device.state = Day(self.device)
                break
            
            if self.device.is_movement():
                self.device.state = Movement(self.device)
                break
            
            sleep(1)
            