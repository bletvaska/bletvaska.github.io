from states.init import Init

class Device():
    def __init__(self):
        self.ldr = None
        self.pir = None
        self.light = None
        self.config = None
        self.state = Init(self)
        
    def get_intensity(self):
        value = int(100 - self.ldr.read_u16() / 65535 * 100)
        print(f'- insensity {value}%')
        return value
    
    def is_movement(self):
        value = self.pir.value() == 1
        print(f'- movement: {value}')
        return value
        
    def run(self):
        while True:
            state = self.state
            
            state.on_enter()
            state.exec()
            state.on_exit()
        